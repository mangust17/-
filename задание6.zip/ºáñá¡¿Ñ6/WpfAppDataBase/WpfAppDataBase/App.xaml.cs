﻿using System;
using System.Windows;
// Ссылка на пространство имен библиотеки DatabaseController
using DatabaseController;
namespace WpfApp
{
    /// <summary>
    /// Логика взаимодействия для App.xaml
    /// </summary>
    public partial class App : Application
    {
        public App()
        {
            string connection_str = @"Data Source=ADCLG1;Initial catalog=OleksenkoPract;Integrated Security=True";
            Database.GetInstance(connection_str);
        }
    }
}
